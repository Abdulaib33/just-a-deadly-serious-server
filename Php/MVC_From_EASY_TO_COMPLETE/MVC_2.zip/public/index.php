<?php

// Chargement de l'init
require_once '../core/init.php';

// Chargement du router 
require_once '../app/routers/index.php';

// Chargement du template
require_once '../app/views/templates/default.php';
