<?php

// Chargement des paramètres 
// Chargement de la connexion

require_once '../app/config/params.php';
require_once '../core/connection.php';
