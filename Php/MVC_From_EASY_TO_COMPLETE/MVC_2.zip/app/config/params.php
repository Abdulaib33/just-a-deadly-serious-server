<?php

// PARAMÈTRES DE CONNEXION
define('DB_NAME', "retro_monsters_2025");
define('DB_HOST', "localhost:8889");
define('DB_USER', "root");
define('DB_PASSWORD', "root");
