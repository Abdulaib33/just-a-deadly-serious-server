<h2><?php echo $monster['name']; ?> - ID: <?php echo $monster['id']; ?></h2>
<ul>
    <li>PV: <?php echo $monster['pv']; ?></li>
    <li>Attack: <?php echo $monster['attack']; ?></li>
    <li>Defense: <?php echo $monster['defense']; ?></li>
</ul>
<p><?php echo $monster['description']; ?></p>