<h2><?php echo $user['pseudo']; ?></h2>
<ul>
    <li>Email: <?php echo $user['email']; ?></li>
    <li>Level: <?php echo $user['level']; ?></li>
</ul>