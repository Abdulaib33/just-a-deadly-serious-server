<h3>Types</h3>
<ul>
    <?php foreach ($types as $type): ?>
        <li>
            <a href="">
                <?php echo $type['name']; ?>
            </a>
        </li>
    <?php endforeach; ?>
</ul>