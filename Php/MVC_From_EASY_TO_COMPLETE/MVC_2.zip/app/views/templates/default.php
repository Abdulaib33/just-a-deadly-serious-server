<!DOCTYPE html>
<html lang="en">

<head>
    <?php include '../app/views/templates/partials/_head.php'; ?>
</head>

<body>
    <?php include '../app/views/templates/partials/_header.php'; ?>

    <?php include '../app/views/templates/partials/_main.php'; ?>

    <?php include '../app/views/templates/partials/_footer.php'; ?>
</body>

</html>