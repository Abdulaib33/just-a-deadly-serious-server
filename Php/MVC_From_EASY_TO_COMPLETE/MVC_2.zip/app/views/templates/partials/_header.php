<header>
    <nav>
        <div class="nav-wrapper container">
            <a href="?" class="brand-logo">RetroMonsters</a>
            <ul id="nav-mobile" class="right">
                <li><a href="?">Monsters</a></li>
                <li><a href="?users">Users</a></li>
                <li><a href="">RetroMonsters Project</a></li>
            </ul>
        </div>
    </nav>
</header>