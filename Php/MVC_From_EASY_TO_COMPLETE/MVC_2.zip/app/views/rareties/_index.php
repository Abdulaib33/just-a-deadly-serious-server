<h3>Rareties</h3>
<ul>
    <?php foreach ($rareties as $rarety): ?>
        <li>
            <a href="">
                <?php echo $rarety['name']; ?>
            </a>
        </li>
    <?php endforeach; ?>
</ul>