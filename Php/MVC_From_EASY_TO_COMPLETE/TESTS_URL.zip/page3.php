<h1>Ceci est la page PAGE 3</h1>
<h2>Page du produit <?php echo $_GET['productID']; ?>: xx</h2>