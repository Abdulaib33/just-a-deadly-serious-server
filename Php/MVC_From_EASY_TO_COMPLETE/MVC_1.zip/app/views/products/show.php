<h2>
    Détails du produit:
    <?php echo $product['name']; ?>
</h2>
<div>Prix: <?php echo $product['price']; ?>€</div>