<?php
// DISPATCHER CENTRAL
// ./public/index.php


// 1. CHARGEMENT DU ROUTER
require_once '../app/routers/index.php';

// 2. CHARGEMENT DU TEMPLATE
require_once '../app/views/templates/default.php';
