<?php

require_once '../core/init.php';

require_once '../app/routers/index.php';

require_once '../app/views/templates/index.php';
