<?php

require_once '../app/config/params.php';
require_once '../core/connexion.php';
require_once '../core/helpers.php';
