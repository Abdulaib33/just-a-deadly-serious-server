# PHOTO HUNTER 2025
Un site web en MVC procédural via un framework artisanal inspiré de LARAVEL.
Le template et la DB sont fournis.

## Instructions
- Téléchargez et dézippez
- Placez le dossier dans la racine de votre serveur web
- Entrez l'URL vers votre dossier du serveur depuis votre navigateur.