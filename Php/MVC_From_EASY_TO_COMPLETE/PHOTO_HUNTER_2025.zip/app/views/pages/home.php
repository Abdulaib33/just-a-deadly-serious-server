<section>
    <h2 class="text-3xl mb-4 font-bold">Dernières photos</h2>
    <?php include '../app/views/photos/_index.php'; ?>
</section>

<section class="mt-16">
    <h2 class="text-3xl mb-4 font-bold">Dernier.ère.s photographes</h2>
    <?php include '../app/views/authors/_index.php'; ?>
</section>