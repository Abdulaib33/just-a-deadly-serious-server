<!DOCTYPE html>
<html lang="fr">

<head>
    <?php include '../app/views/templates/partials/_head.php'; ?>
</head>

<body class="bg-gray-300">
    <?php include '../app/views/templates/partials/_nav.php'; ?>

    <?php include '../app/views/templates/partials/_main.php'; ?>

    <?php include '../app/views/templates/partials/_footer.php'; ?>
</body>

</html>