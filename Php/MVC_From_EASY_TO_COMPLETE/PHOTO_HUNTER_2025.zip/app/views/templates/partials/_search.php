<form action="" class="mb-8">
    <input type="text" placeholder="search">
    <input type="submit" value="Search">
</form>