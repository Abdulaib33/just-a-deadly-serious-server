<aside class="p-4 md:w-1/3">
    <div class="h-full p-6">
        <?php include '../app/views/templates/partials/_search.php'; ?>
        <?php include '../app/views/categories/_index.php'; ?>
    </div>
</aside>