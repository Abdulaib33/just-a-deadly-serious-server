<footer class="bg-white shadow-md">
    <div class="max-w-7xl mx-auto py-4 px-5">
        <p class="text-center text-base text-gray-600">
            © 2024 PHOTO HUNTER LIGHT. Tous droits réservés.
        </p>
    </div>
</footer>