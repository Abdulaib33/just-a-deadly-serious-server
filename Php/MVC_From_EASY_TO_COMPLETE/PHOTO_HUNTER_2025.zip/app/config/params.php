<?php

// Initialisation des zones dynamiques
$content = "";

// Paramètres de connexion
define('DB_HOST', '127.0.0.1:8889');
define('DB_NAME', 'photo_hunter');
define('DB_USER', 'root');
define('DB_PASSWORD', 'root');
